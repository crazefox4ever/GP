import cv2
import time
import numpy as np


class VideoCamera(object):
    def __init__(self):
        self.cap = cv2.VideoCapture(0)
        time.sleep(2)

    def __del__(self):
        self.cap.release()

    def get_frame(self):
        _, frame = self.cap.read()
        ret, jpeg = cv2.imencode('.jpg', frame)
        return jpeg.tobytes()

    def get_object(self, classifier):
        _, frame = self.cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        objects = classifier.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30),
            flags=cv2.CASCADE_SCALE_IMAGE
        )

        # Draw a rectangle around the objects
        for (x, y, w, h) in objects:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 140, 125), 2)

        ret, jpeg = cv2.imencode('.jpg', frame)
        return jpeg.tobytes()


