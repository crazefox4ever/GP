from datetime import datetime,date
from flask import Flask,render_template,flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine, MetaData, Table, desc
from sqlalchemy.orm import mapper, sessionmaker
import argparse
from cv2 import cv2
import calendar
import base64



# problem with mac os + mysql remove in rasberypi
# using pip install PyMySQL
import pymysql
pymysql.install_as_MySQLdb()



class sds(object):
    pass

def loadSession():
    """"""    
    # to conncet with mysql that run on raperry pi :
    # engine = create_engine('mysql://root:pass@192.168.1.10:3306/sds', echo=True) 
    engine = create_engine('mysql://root:password123@localhost:3306/sds', echo=False)
    
    metadata = MetaData(engine)

    metadata.reflect(bind=engine)
    conn = engine.connect()

    violations = Table('violations', metadata, autoload=True)
    mapper(sds, violations)
    
    Session = sessionmaker(bind=engine)
    session = Session()
    return session,conn,violations





session,conn,violations = loadSession()

# Parse the arguments from command line
arg = argparse.ArgumentParser(description='Social distance detection')

#temp = True

def Violation_detected(Type):
    now = datetime.now()
    viol_date = now.strftime("%d/%m/%Y")
    viol_time = now.strftime("%H:%M:%S")
    Type = Type.lower()
    Insert_Data(Type,viol_date,viol_time)
    


def Insert_Data(type,date,time):
    # with open('violation'+str(id)+'.jpg',"rb") as f:
    # binary_img = f.read()

    with open ("image_test.jpeg",'rb') as f:
        binary_img = f.read()
        
  
    conn.execute(violations.insert(), {"Type": type,"Date": date,"Time": time,"Image" : binary_img })


def get_No_of_rows():
    result = session.query(violations.c.ID).count()
    return result

def get_ID_all():
    result = session.query(violations.c.ID).all()
    return result

def get_all():
    result = session.query(violations).all()
    return result

def get_ID(id):
    data = {}
    try:
        result = session.query(violations).filter_by(ID = id).first()
        data ={
            "ID":result.ID,
            "Type": result.Type,
            "Date":result.Date,
            "Time":result.Time,
            "Image":result.Image
        }
    except:
        flash("The ID: "+id+" Does not exist")
    return  data

def get_Type_all():
    result =  session.query(violations.c.Type).all()  
    data = []

    for vtype in result:
        data.append({
        "ID":vtype.ID,
        "Type": vtype.Type,
        "Date":vtype.Date,
        "Time":vtype.Time,
        "Image":vtype.Image
        })

    return  data 
     

def get_Type(type):
    result = session.query(violations).filter_by(Type = type).all()
    data = []

    for vtype in result:
        data.append({
        "ID":vtype.ID,
        "Type": vtype.Type,
        "Date":vtype.Date,
        "Time":vtype.Time,
        "Image":vtype.Image
        })
    

    return  data

 

def getDay(id):
    result = get_ID(id)
    date=(result["Date"])
    day = datetime.strptime(date, '%d/%m/%Y').weekday()
    theday = ""
    if (day == 0):
        theday = "Monday"
    elif (day == 1):
        theday = "Tuesday"
    elif(day == 2):
        theday = "Wednesday"    
    elif (day == 3):
        theday = "Thursday"  
    elif (day == 4):
        theday = "Friday"
    elif (day == 5):
        theday ='Saturday'
    elif (day == 6):
        theday = "Sunday"    
    else:
        theday = "Uknown"

    return theday



def get_Image(id):
    result = session.query(violations).filter_by(ID = id).first()
    return result.Image 

def get_all_images():
    result = session.query(violations.c.Image).all()
    return result

